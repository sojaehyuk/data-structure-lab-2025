A = {
    0: [1, 2, 3],
    1: [0, 2, 4, 5],
    2: [0, 1, 6],
    3: [0],
    4: [1],
    5: [1],
    6: [2]
}

from collections import deque

def bfs(A):
    """
    너비 우선 탐색(BFS)으로 그래프를 탐색하여 방문한 노드의 순서를 반환합니다.
    
    매개변수:
        A (dict): 각 노드별 인접 노드 리스트로 구성된 그래프(인접 리스트).
    
    반환값:
        list: BFS로 탐색한 노드 방문 순서 리스트.
    
    특징:
        - 시작 노드는 0번입니다.
        - 같은 레벨에서는 더 작은 번호의 노드를 먼저 방문합니다.
        - 큐(Queue) 자료구조를 사용합니다.
    """
    answer = []                           # 방문 순서 기록용 리스트
    visited = set()                       # 방문한 노드 집합
    queue = deque([0])                    # BFS용 큐, 시작 노드 0 삽입
    visited.add(0)                        # 시작 노드 방문 처리
    while queue:
        node = queue.popleft()            # 큐에서 노드 꺼내기
        answer.append(node)               # 방문 순서에 추가
        for neighbor in sorted(A[node]):  # 인접 노드를 작은 번호부터 확인
            if neighbor not in visited:   # 아직 방문 안 했으면
                visited.add(neighbor)     # 방문 처리
                queue.append(neighbor)    # 큐에 삽입
    return answer

def dfs(A):
    """
    깊이 우선 탐색(DFS)으로 그래프를 탐색하여 방문한 노드의 순서를 반환합니다.
    
    매개변수:
        A (dict): 각 노드별 인접 노드 리스트로 구성된 그래프(인접 리스트).
    
    반환값:
        list: DFS로 탐색한 노드 방문 순서 리스트.
    
    특징:
        - 시작 노드는 0번입니다.
        - 같은 깊이에서는 더 작은 번호의 노드를 먼저 방문합니다.
        - 스택(Stack) 자료구조를 사용하며, 인접 노드를 큰 번호부터 스택에 넣어 작은 번호가 먼저 탐색되도록 합니다.
    """
    answer = []                             # 방문 순서 기록용 리스트
    visited = set()                         # 방문한 노드 집합
    stack = [0]                             # DFS용 스택, 시작 노드 0 삽입
    visited.add(0)                          # 시작 노드 방문 처리

    while stack:
        node = stack.pop()                  # 스택에서 노드 꺼내기
        answer.append(node)                 # 방문 순서에 추가

        # 인접 노드를 큰 번호부터 스택에 삽입 (작은 번호가 먼저 pop되도록)
        for neighbor in sorted(A[node], reverse=True):
            if neighbor not in visited:     # 아직 방문 안 했으면
                visited.add(neighbor)       # 방문 처리 (스택에 넣을 때)
                stack.append(neighbor)      # 스택에 삽입
    return answer

# 아래는 체크함수입니다. 수정하실 필요 없습니다.
bfs_result = bfs(A)
dfs_result = dfs(A)

assert bfs_result == [0,1,2,3,4,5,6]
assert dfs_result == [0,1,4,5,2,6,3]
print('PASSED!')


