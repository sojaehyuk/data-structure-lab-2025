import sys

## 입력 받는 코드입니다. 수정할 필요 없습니다.
sys.stdin = open('case.txt')
N, M = list(map(int,input().split()))
#print(N, M)
concerts = []
for v in range(N):
    values = list(map(int, input().split()))
    concerts.append(values)
# print(concerts)
# [[1, 0, 0, 1, 1, 0], [1, 0, 1, 1, 0, 0], [1, 1, 1, 1, 0, 1], [0, 1, 1, 0, 1, 1], [0, 1, 0, 0, 1, 0]]
###################################

def count_zero_areas(concerts):
    """
    2차원 배열 concerts에서 0(빈 공간)으로 연결된 공간(connected component)의 개수를 반환합니다.

    매개변수:
        concerts (list of list of int): 콘서트장 약도를 나타내는 2차원 리스트 (0: 빈 공간, 1: 펜스 공간)

    반환값:
        int: 0으로 연결된 독립된 공간(덩어리)의 개수

    특징:
        - 상하좌우 네 방향으로 연결된 0만 같은 공간으로 간주합니다.
        - BFS(너비 우선 탐색)를 사용하여 각 0 덩어리를 한 번씩만 탐색합니다.
        - 입력이 비어 있거나 첫 행이 없는 경우 0을 반환합니다.
    """
    if not concerts or not concerts[0]:
        return 0

    N = len(concerts)         # 행의 개수
    M = len(concerts[0])      # 열의 개수
    visited = [[False]*M for _ in range(N)]  # 방문 여부 체크용 2차원 배열
    answer = 0                # 0으로 연결된 공간(덩어리) 개수

    dx = [0, 0, 1, -1]        # 상, 하, 우, 좌 방향 이동값 (행)
    dy = [1, -1, 0, 0]        # 상, 하, 우, 좌 방향 이동값 (열)

    from collections import deque  # BFS를 위한 deque 임포트

    def bfs(sx, sy):
        """
        (sx, sy)에서 시작하여 연결된 모든 0을 BFS로 방문 처리합니다.
        """
        queue = deque()
        queue.append((sx, sy))
        visited[sx][sy] = True
        while queue:
            x, y = queue.popleft()
            for dir in range(4):
                nx = x + dx[dir]
                ny = y + dy[dir]
                # 인덱스가 행렬 범위 내에 있는지 확인
                if 0 <= nx < N and 0 <= ny < M:
                    # 0이면서 아직 방문하지 않은 칸이면
                    if concerts[nx][ny] == 0 and not visited[nx][ny]:
                        visited[nx][ny] = True
                        queue.append((nx, ny))

    # 모든 좌표를 돌며, 방문하지 않은 0을 발견하면 bfs 실행
    for i in range(N):
        for j in range(M):
            if concerts[i][j] == 0 and not visited[i][j]:
                bfs(i, j)       # 해당 0에서 연결된 모든 0 방문 처리
                answer += 1     # 새로운 0 공간(덩어리) 발견 시 카운트 증가

    return answer

print(count_zero_areas(concerts))  # 0으로 연결된 빈공간 개수 출력
